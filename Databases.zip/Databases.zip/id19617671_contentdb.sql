-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 25, 2022 at 03:33 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id19617671_contentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataCollection`
--

CREATE TABLE `dataCollection` (
  `subjectID` int(20) NOT NULL,
  `contentID` int(20) NOT NULL,
  `topics` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ytLink` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Q1` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `Q2` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `favourite` int(1) DEFAULT 0,
  `note` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dataCollection`
--

INSERT INTO `dataCollection` (`subjectID`, `contentID`, `topics`, `ytLink`, `Q1`, `Q2`, `favourite`, `note`) VALUES
(1, 1, 'Data Types', 'https://youtu.be/EcUGDTs4RyY', 'Name all data types and functionality.', ' Primitive and Non-primitive data types', 0, 'A data type, in programming, is a classification that specifies which type of value a variable has and what type of mathematical, relational or logical operations can be applied to it without causing an error. A string, for example, is a data type that is used to classify text and an integer is a data type used to classify whole numbers.'),
(1, 2, 'Data structure and Types', 'https://youtu.be/5g7K86jYto8', 'Linear and non-linear data structures.', 'List and explain Linear DS.', 0, 'Data structure is a storage that is used to store and organize data. It is a way of arranging data on a computer so that it can be accessed and updated efficiently.'),
(2, 6, 'Stack', 'https://youtu.be/r2yHEW8HmBE', 'Q1. Sample question 1', 'Q2. Sample question 2', 0, 'A sample note!'),
(2, 8, 'Graphs', 'https://www.youtube.com/watch?v=zv0ba0Iok1Y', 'Q1. Sample question 1', 'Q2. Sample question 2', 0, 'a sample note');

-- --------------------------------------------------------

--
-- Table structure for table `dataCollection2`
--

CREATE TABLE `dataCollection2` (
  `contentID` int(20) NOT NULL,
  `topics` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `ytLink` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Q1` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `Q2` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `favourite` int(1) NOT NULL DEFAULT 0,
  `note` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dataCollection2`
--

INSERT INTO `dataCollection2` (`contentID`, `topics`, `ytLink`, `Q1`, `Q2`, `favourite`, `note`) VALUES
(1, 'Queue', 'https://www.youtube.com/watch?v=UbAEP7P0vfk', 'sample question 1', 'saqmple question 2', 0, 'sample note'),
(3, 'graph', 'https://www.youtube.com/watch?v=zv0ba0Iok1Y', 'sample question 1', 'sample question 2', 0, 'sample note');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectID` int(20) NOT NULL,
  `subjectName` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectID`, `subjectName`) VALUES
(1, 'Data Structures And Algorithms'),
(2, 'Programming with C');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataCollection`
--
ALTER TABLE `dataCollection`
  ADD PRIMARY KEY (`contentID`);

--
-- Indexes for table `dataCollection2`
--
ALTER TABLE `dataCollection2`
  ADD PRIMARY KEY (`contentID`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataCollection`
--
ALTER TABLE `dataCollection`
  MODIFY `contentID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dataCollection2`
--
ALTER TABLE `dataCollection2`
  MODIFY `contentID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subjectID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
