<?php




include 'content_con.php';
$sql= "SELECT contentId, topics, ytLink,concat(Q1,CHAR(10),Q2) as question,note FROM  dataCollection";
$result=mysqli_query($con,$sql)
if (mysqli_num_rows($test)>0){
    $output = mysqli_fetch_all($result,MYSQLI_ASSOC);
    echo json_encode($output);
}
else
{
    echo json_encode(array('message'=>'no record found','status'=>'false'))
}
?>