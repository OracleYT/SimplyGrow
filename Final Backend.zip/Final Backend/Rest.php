<?php
class Rest{
    private $host  = 'localhost';
    private $user  = 'id9617671_contentdatabase';
    private $password   = "Yi7-@a6o4egeTo%0";
    private $database  = "webdamn_demos";      
    private $contentTable = 'dataCollection';	
	private $dbConnect = false;
    public function __construct(){
        if(!$this->dbConnect){ 
            $conn = new mysqli($this->host, $this->user, $this->password, $this->database);
            if($conn->connect_error){
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            }else{
                $this->dbConnect = $conn;
            }
        }
    }
	private function getData($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$data= array();
		while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
			$data[]=$row;            
		}
		return $data;
	}
	private function getNumRows($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}

	function getContent($contentId) {		
		$sqlQuery = '';
		if($contentId) {
			$sqlQuery = "WHERE id = '".$contentId."'";
		}	
		$contentQuery = "
			SELECT contentId, topics, ytLink,concat(Q1,CHAR(10),Q2) as question,note 
			FROM ".$this->dataCollection." $sqlQuery
			ORDER BY id DESC";	
		$resultData = mysqli_query($this->dbConnect, $contentQuery);
		$contentData = array();
		while( $contentRecord = mysqli_fetch_assoc($resultData) ) {
			$contentData[] = $contentRecord;
		}
		header('Content-Type: application/json');
		echo json_encode($contentData);	
	}
}
?>