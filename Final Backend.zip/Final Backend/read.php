<?php

require 'content_con.php';

// function getContent($contentId) {		
// 	$sqlQuery = '';
// 	if($contentId) {
// 		$sqlQuery = "WHERE id = '".$contentId."'";
// 	}	
// 	$contentQuery = "
// 		SELECT contentId, topics, ytLink,concat(Q1,CHAR(10),Q2) as question,note 
// 		FROM ".$this->dataCollection." $sqlQuery
// 		ORDER BY id DESC";	
// 	$resultData = mysqli_query($this->dbConnect, $contentQuery);
// 	$contentData = array();
// 	while( $contentRecord = mysqli_fetch_assoc($resultData) ) {
// 		$contentData[] = $contentRecord;
// 	}
// 	header('Content-Type: application/json');
// 	echo json_encode($contentData);	
// }

$requestMethod = $_SERVER["REQUEST_METHOD"];
include('Rest.php');
$api = new Rest();
switch($requestMethod) {
	case 'GET':
		$contentId = '';	
		if($_GET['id']) {
			$contentId = $_GET['id'];
		}
		$api->getContent($contentId);
		break;
	default:
	header("HTTP/1.0 405 Method Not Allowed");
	break;
}

?>

